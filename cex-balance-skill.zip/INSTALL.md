# CEX Balance Skill - Installation Guide

Quick installation guide for the CEX Balance skill for Claude Code.

## Installation Steps

### Option 1: Manual Installation (Recommended)

1. **Extract the archive** to your Claude Code skills directory:
```bash
# On macOS/Linux
unzip cex-balance.zip -d ~/.claude/skills/

# On Windows
# Extract to: %USERPROFILE%\.claude\skills\
```

2. **Navigate to the skill directory**:
```bash
cd ~/.claude/skills/cex-balance
# or on Windows: cd %USERPROFILE%\.claude\skills\cex-balance
```

3. **Install dependencies**:
```bash
npm install
```

4. **Configure API keys**:
```bash
cp .env.example .env
```

Then edit `.env` with your READ-ONLY exchange API keys.

5. **Test the skill**:
```bash
npm start
```

You should see "No exchanges configured" if you haven't added API keys yet, or your balances if you have.

### Option 2: Project-Level Installation

Install in a specific project's `.claude/skills/` directory:

```bash
# Extract to project directory
unzip cex-balance.zip -d /path/to/your/project/.claude/skills/

# Install dependencies
cd /path/to/your/project/.claude/skills/cex-balance
npm install

# Configure
cp .env.example .env
# Edit .env with your API keys
```

## Usage in Claude Code

Once installed, use these commands in Claude Code chat:

```
/cex-balance              # Check all exchanges
/cex-balance binance      # Check only Binance
/cex-balance --summary    # Show summary only
```

## Creating READ-ONLY API Keys

⚠️ **CRITICAL:** Only use READ-ONLY API keys! Never enable trading/withdrawal permissions.

### Binance
1. Visit https://www.binance.com/en/my/settings/api-management
2. Create new API key
3. Enable ONLY "Read" permission
4. Disable all other permissions

### KuCoin
1. Visit https://www.kucoin.com/account/api
2. Create new API key
3. Enable ONLY "General" (read-only) permission

### Gate.io
1. Visit https://www.gate.io/myaccount/api_key_manage
2. Create new APIv4 key
3. Enable ONLY read permissions

## Security Checklist

- ✅ API keys stored locally in `.env` file
- ✅ Only READ-ONLY permissions enabled on exchanges
- ✅ `.env` file is gitignored (never committed)
- ✅ IP whitelisting enabled on exchanges (optional but recommended)

## Troubleshooting

**"Cannot find module 'ccxt'"**
- Run `npm install` in the skill directory

**"No exchanges configured"**
- Check that `.env` file exists
- Verify API keys are correct
- Make sure you're running from the skill directory

**Permission errors**
- Ensure API keys have read permissions enabled on exchange
- Some earn/savings products may require additional permissions

## Support

- GitHub: https://github.com/dns7030/cexPortofolioTracker/tree/skill
- Issues: https://github.com/dns7030/cexPortofolioTracker/issues

## Disclaimer

This skill stores API keys locally. You are fully responsible for securing your API keys. The authors take NO RESPONSIBILITY for any losses. USE AT YOUR OWN RISK.
